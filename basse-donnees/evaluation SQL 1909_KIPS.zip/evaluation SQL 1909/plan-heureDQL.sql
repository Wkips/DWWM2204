SELECT plane_ref,plane_autonomy,plane_speed
FROM planes
ORDER BY plane_speed ASC;

SELECT  plane_ref,plane_capacity,plane_autonomy,plane_maker
FROM planes
INNER JOIN planes ON manufacturers.plane_maker_id = planes.plane_maker_id
ORDER BY plane_maker ASC, plane_autonomy ASC;

